package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModelProvider
import com.example.ui.components.CyberBackground
import com.example.ui.components.CyberCyan
import com.example.ui.components.CyberPink
import com.example.ui.components.GlassBorder
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.MainHubScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.UpdatesScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.Screen
import com.example.viewmodel.VibeViewModel
import com.example.viewmodel.VibeViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Safely extract Repository from Application container
        val repository = (application as VibeApplication).container.repository

        // Build ViewModel using Factory (Constructor Injection)
        val viewModel = ViewModelProvider(this, VibeViewModelFactory(repository))[VibeViewModel::class.java]

        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    // Main Cyber Grid backdrop
                    CyberBackground(modifier = Modifier.padding(innerPadding)) {
                        AppNavigationContainer(viewModel = viewModel)
                    }
                }
            }
        }
    }
}

@Composable
fun AppNavigationContainer(
    viewModel: VibeViewModel,
    modifier: Modifier = Modifier
) {
    val currentScreen by viewModel.currentScreen.collectAsState()

    when (currentScreen) {
        Screen.Onboarding -> {
            OnboardingScreen(viewModel = viewModel, modifier = modifier)
        }
        Screen.ChatDetail -> {
            ChatScreen(viewModel = viewModel, modifier = modifier)
        }
        Screen.MainHub, Screen.Updates -> {
            // Master layout with elegant Frosted Glass bottom navigation bar
            Column(modifier = modifier.fillMaxSize()) {
                Box(modifier = Modifier.weight(1f)) {
                    if (currentScreen == Screen.MainHub) {
                        MainHubScreen(viewModel = viewModel)
                    } else {
                        UpdatesScreen(viewModel = viewModel)
                    }
                }

                // Custom High-Index Frosted Bottom Navigation Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding() // Safely padding standard device navigation bar gesture area
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                        .clip(RoundedCornerShape(24.dp))
                        .background(Color(0x19FFFFFF))
                        .border(1.dp, GlassBorder.copy(alpha = 0.2f), RoundedCornerShape(24.dp))
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Chats Tab (touch target 48dp+ for standard accessibility)
                    Row(
                        modifier = Modifier
                            .testTag("nav_chats_tab")
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (currentScreen == Screen.MainHub) CyberCyan.copy(alpha = 0.2f) else Color.Transparent)
                            .clickable { viewModel.setScreen(Screen.MainHub) }
                            .padding(horizontal = 24.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ChatBubble,
                            contentDescription = "Chats Tab",
                            tint = if (currentScreen == Screen.MainHub) CyberCyan else Color.Gray,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "CHATS",
                            color = if (currentScreen == Screen.MainHub) Color.White else Color.Gray,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    // Updates Tab (touch target 48dp+ for standard accessibility)
                    Row(
                        modifier = Modifier
                            .testTag("nav_updates_tab")
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (currentScreen == Screen.Updates) CyberPink.copy(alpha = 0.2f) else Color.Transparent)
                            .clickable { viewModel.setScreen(Screen.Updates) }
                            .padding(horizontal = 24.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ElectricBolt,
                            contentDescription = "Updates Tab",
                            tint = if (currentScreen == Screen.Updates) CyberPink else Color.Gray,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "UPDATES",
                            color = if (currentScreen == Screen.Updates) Color.White else Color.Gray,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}
