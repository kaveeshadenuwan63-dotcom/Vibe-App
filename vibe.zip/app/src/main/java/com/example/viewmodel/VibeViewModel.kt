package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.Contact
import com.example.data.Message
import com.example.data.Repository
import com.example.data.StatusUpdate
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class Screen {
    Onboarding,
    MainHub,
    ChatDetail,
    Updates
}

class VibeViewModel(private val repository: Repository) : ViewModel() {

    // UI state flows
    val allContacts = repository.allContacts.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allStatusUpdates = repository.allStatusUpdates.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allMessages = repository.allMessages.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentScreen = MutableStateFlow(Screen.Onboarding)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _loggedInPhone = MutableStateFlow<String?>(null)
    val loggedInPhone: StateFlow<String?> = _loggedInPhone.asStateFlow()

    private val _loggedInName = MutableStateFlow<String?>(null)
    val loggedInName: StateFlow<String?> = _loggedInName.asStateFlow()

    private val _selectedChatId = MutableStateFlow<String?>(null)
    val selectedChatId: StateFlow<String?> = _selectedChatId.asStateFlow()

    private val _selectedChatName = MutableStateFlow<String?>(null)
    val selectedChatName: StateFlow<String?> = _selectedChatName.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _isAiProxyEnabled = MutableStateFlow(false)
    val isAiProxyEnabled: StateFlow<Boolean> = _isAiProxyEnabled.asStateFlow()

    private val _isNeuralLinkEnabled = MutableStateFlow(true)
    val isNeuralLinkEnabled: StateFlow<Boolean> = _isNeuralLinkEnabled.asStateFlow()

    // Fluctuating BPM flow for active chat headers
    private val _liveBpm = MutableStateFlow(75)
    val liveBpm: StateFlow<Int> = _liveBpm.asStateFlow()

    // Quick status typing
    private val _userStatusText = MutableStateFlow("")
    val userStatusText: StateFlow<String> = _userStatusText.asStateFlow()

    init {
        // Start simulated BPM fluctuations
        viewModelScope.launch {
            while (true) {
                delay(1500)
                val base = _selectedChatId.value?.let { chatId ->
                    allContacts.value.firstOrNull { it.phoneNumber == chatId }?.baseBpm
                } ?: 75
                _liveBpm.value = base + Random.nextInt(-4, 5)
            }
        }
    }

    fun setScreen(screen: Screen) {
        _currentScreen.value = screen
    }

    fun selectChat(chatId: String, name: String) {
        _selectedChatId.value = chatId
        _selectedChatName.value = name
        _currentScreen.value = Screen.ChatDetail
    }

    fun setQuery(query: String) {
        _searchQuery.value = query
    }

    fun login(phone: String, name: String) {
        _loggedInPhone.value = phone
        _loggedInName.value = name
        _currentScreen.value = Screen.MainHub
    }

    fun logout() {
        _loggedInPhone.value = null
        _loggedInName.value = null
        _currentScreen.value = Screen.Onboarding
    }

    fun toggleAiProxy() {
        _isAiProxyEnabled.value = !_isAiProxyEnabled.value
    }

    fun toggleNeuralLink() {
        _isNeuralLinkEnabled.value = !_isNeuralLinkEnabled.value
    }

    fun saveNewContact(name: String, phoneNumber: String) {
        viewModelScope.launch {
            repository.saveContact(name, phoneNumber, isSynced = false)
        }
    }

    fun postUserStatus(text: String, mood: String) {
        val phone = _loggedInPhone.value ?: "+1 2040-USER"
        val name = _loggedInName.value ?: "You (Neural Core)"
        viewModelScope.launch {
            repository.addStatusUpdate(phone, name, text, mood)
        }
    }

    fun sendMessage(content: String, holographicMediaUrl: String? = null) {
        val chatId = _selectedChatId.value ?: return
        viewModelScope.launch {
            // 1. Send our message
            repository.sendMessage(
                chatId = chatId,
                senderName = "You",
                senderPhone = "me",
                content = content,
                isIncoming = false,
                holographicMediaUrl = holographicMediaUrl
            )

            // Simulate futuristic reply after a short delay
            delay(1200)
            triggerSimulatedReply(chatId, content)
        }
    }

    private suspend fun triggerSimulatedReply(chatId: String, userMessage: String) {
        val contactName = _selectedChatName.value ?: "Neural Link"
        
        // Pick appropriate futuristic response based on user input or random
        val (rawReply, translated) = getFuturisticReplyAndTranslation(contactName, userMessage)

        if (_isAiProxyEnabled.value) {
            // AI Proxy is enabled: It intercepts and replies automatically on our behalf first!
            val proxyReply = getAiProxyInterceptReply(contactName, userMessage)
            repository.sendMessage(
                chatId = chatId,
                senderName = "AI Proxy (You)",
                senderPhone = "me_proxy",
                content = proxyReply,
                isIncoming = false
            )
            
            delay(1000)
            // Then the contact replies
            repository.sendMessage(
                chatId = chatId,
                senderName = contactName,
                senderPhone = chatId,
                content = rawReply,
                translatedContent = if (_isNeuralLinkEnabled.value) translated else null,
                isIncoming = true
            )
        } else {
            // Standard reply from contact
            repository.sendMessage(
                chatId = chatId,
                senderName = contactName,
                senderPhone = chatId,
                content = rawReply,
                translatedContent = if (_isNeuralLinkEnabled.value) translated else null,
                isIncoming = true
            )
        }
    }

    private fun getFuturisticReplyAndTranslation(sender: String, message: String): Pair<String, String> {
        val lower = message.lowercase()
        return when {
            lower.contains("hello") || lower.contains("hi") || lower.contains("hey") -> {
                Pair(
                    "神経ネットワーク同期完了。調子はどう？",
                    "Neural network sync complete. How are you doing?"
                )
            }
            lower.contains("holo") || lower.contains("media") || lower.contains("clip") -> {
                Pair(
                    "ホログラフィック・パッケージ送信。3Dグリッドを展開してください。",
                    "Holographic packet sent. Please deploy the 3D grid projection."
                )
            }
            lower.contains("status") || lower.contains("bpm") || lower.contains("heart") -> {
                Pair(
                    "私の生体センサーは完全に正常です。ストレスレベルはゼロです。",
                    "My biometric sensors are perfectly normal. Stress levels are minimal."
                )
            }
            else -> {
                val list = listOf(
                    Pair("マトリックスが更新されました。次のノードで会いましょう。", "Matrix has updated. See you at the next node."),
                    Pair("データを送信中。Neural Linkプロトコルが稼働しています。", "Sending payload. Neural Link protocols are online."),
                    Pair("サイバーネティクスの最適化が行われています。遅延が極小化されました。", "Cybernetic optimizations are underway. Latency is minimized.")
                )
                list.random()
            }
        }
    }

    private fun getAiProxyInterceptReply(sender: String, message: String): String {
        val responses = listOf(
            "[AI Proxy Clone V4.2] User is resting. Bio-feed records deep-cycle sleep. Re-routing payload.",
            "[AI Proxy Clone V4.2] Holographic overlay busy. I will archive this transmission.",
            "[AI Proxy Clone V4.2] Autonomous responder active. Message read: Neural link latency handled.",
            "[AI Proxy Clone V4.2] Deep grid connection in progress. Auto-logged response injected."
        )
        return responses.random()
    }

    // Manual simulation of an incoming text from outside
    fun simulateIncomingText(phone: String, name: String, text: String, translated: String? = null) {
        viewModelScope.launch {
            if (_isAiProxyEnabled.value) {
                // Instantly log contact text
                repository.sendMessage(chatId = phone, senderName = name, senderPhone = phone, content = text, translatedContent = if (_isNeuralLinkEnabled.value) translated else null, isIncoming = true)
                delay(800)
                // Intercept with Proxy Auto Reply
                val proxyReply = getAiProxyInterceptReply(name, text)
                repository.sendMessage(chatId = phone, senderName = "AI Proxy (You)", senderPhone = "me_proxy", content = proxyReply, isIncoming = false)
            } else {
                repository.sendMessage(chatId = phone, senderName = name, senderPhone = phone, content = text, translatedContent = if (_isNeuralLinkEnabled.value) translated else null, isIncoming = true)
            }
        }
    }
}

class VibeViewModelFactory(private val repository: Repository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(VibeViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return VibeViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
