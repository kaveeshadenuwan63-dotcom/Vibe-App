package com.example

import android.app.Application
import com.example.data.AppDatabase
import com.example.data.Repository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class AppContainer(private val application: Application) {
    val database: AppDatabase by lazy { AppDatabase.getDatabase(application) }
    val repository: Repository by lazy { Repository(database) }
}

class VibeApplication : Application() {
    lateinit var container: AppContainer
    private val applicationScope = CoroutineScope(SupervisorJob())

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        
        // Prepopulate the database asynchronously if it is empty
        applicationScope.launch {
            container.repository.prepopulateIfEmpty()
        }
    }
}
