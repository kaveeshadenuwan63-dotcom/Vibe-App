package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "contacts")
data class Contact(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val phoneNumber: String,
    val isSynced: Boolean = false,
    val avatarSeed: Int = (1..1000).random(),
    val currentMood: String = "Calm", // "Calm", "Highly Excited", "Cortisol-Stressed"
    val baseBpm: Int = (65..95).random()
)

@Entity(tableName = "messages")
data class Message(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val chatId: String, // phoneNumber for direct chats, or group name like "NEO-TOKYO CORE"
    val senderName: String,
    val senderPhone: String,
    val content: String,
    val translatedContent: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val isIncoming: Boolean = true,
    val isUnread: Boolean = false,
    val holographicMediaUrl: String? = null // if containing holographic visual clip simulation
)

@Entity(tableName = "status_updates")
data class StatusUpdate(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val contactPhone: String,
    val contactName: String,
    val statusText: String,
    val mood: String, // "Calm", "Highly Excited", "Cortisol-Stressed"
    val timestamp: Long = System.currentTimeMillis(),
    val avatarSeed: Int = (1..1000).random()
)
