package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import java.util.UUID

class Repository(private val database: AppDatabase) {

    private val contactDao = database.contactDao()
    private val messageDao = database.messageDao()
    private val statusUpdateDao = database.statusUpdateDao()

    val allContacts: Flow<List<Contact>> = contactDao.getAllContactsFlow()
    val allStatusUpdates: Flow<List<StatusUpdate>> = statusUpdateDao.getAllStatusUpdatesFlow()
    val allMessages: Flow<List<Message>> = messageDao.getAllMessagesFlow()

    fun getMessagesForChat(chatId: String): Flow<List<Message>> {
        return messageDao.getMessagesForChatFlow(chatId)
    }

    suspend fun saveContact(name: String, phoneNumber: String, isSynced: Boolean = false) {
        val existing = contactDao.getContactByPhone(phoneNumber)
        if (existing == null) {
            val mood = listOf("Calm", "Highly Excited", "Cortisol-Stressed").random()
            val contact = Contact(
                name = name,
                phoneNumber = phoneNumber,
                isSynced = isSynced,
                currentMood = mood,
                baseBpm = (60..120).random()
            )
            contactDao.insertContact(contact)
        }
    }

    suspend fun sendMessage(
        chatId: String,
        senderName: String,
        senderPhone: String,
        content: String,
        isIncoming: Boolean,
        holographicMediaUrl: String? = null,
        translatedContent: String? = null
    ): Message {
        val message = Message(
            chatId = chatId,
            senderName = senderName,
            senderPhone = senderPhone,
            content = content,
            translatedContent = translatedContent,
            isIncoming = isIncoming,
            holographicMediaUrl = holographicMediaUrl,
            timestamp = System.currentTimeMillis()
        )
        messageDao.insertMessage(message)
        return message
    }

    suspend fun addStatusUpdate(contactPhone: String, contactName: String, statusText: String, mood: String) {
        // delete existing status update for this phone to avoid duplication
        statusUpdateDao.deleteStatusUpdatesForPhone(contactPhone)
        val status = StatusUpdate(
            contactPhone = contactPhone,
            contactName = contactName,
            statusText = statusText,
            mood = mood,
            timestamp = System.currentTimeMillis()
        )
        statusUpdateDao.insertStatusUpdate(status)
    }

    suspend fun deleteContact(contact: Contact) {
        contactDao.deleteContact(contact)
    }

    suspend fun clearChat(chatId: String) {
        messageDao.deleteChatMessages(chatId)
    }

    suspend fun prepopulateIfEmpty() {
        if (contactDao.getContactCount() == 0) {
            // 1. Insert simulated 2040 contacts
            val initialContacts = listOf(
                Contact(name = "Neo-Tokyo Admin", phoneNumber = "+81 2040-001", isSynced = true, currentMood = "Calm", baseBpm = 72),
                Contact(name = "Vespera (Nexus Core)", phoneNumber = "+1 888-NEO-GRID", isSynced = true, currentMood = "Highly Excited", baseBpm = 118),
                Contact(name = "Aether-9 Bio-Link", phoneNumber = "+44 2040-777", isSynced = true, currentMood = "Cortisol-Stressed", baseBpm = 142),
                Contact(name = "Kaelen (Off-Grid)", phoneNumber = "+61 491-570", isSynced = false, currentMood = "Calm", baseBpm = 64)
            )
            for (contact in initialContacts) {
                contactDao.insertContact(contact)
            }

            // 2. Insert Status updates
            val initialStatuses = listOf(
                StatusUpdate(
                    contactPhone = "+81 2040-001",
                    contactName = "Neo-Tokyo Admin",
                    statusText = "All neural nodes functional. Grid calibration 100%.",
                    mood = "Calm",
                    timestamp = System.currentTimeMillis() - 3600000
                ),
                StatusUpdate(
                    contactPhone = "+1 888-NEO-GRID",
                    contactName = "Vespera (Nexus Core)",
                    statusText = "Cybernetic rave at the Spark Core tonight! Free bio-cocktails!",
                    mood = "Highly Excited",
                    timestamp = System.currentTimeMillis() - 7200000
                ),
                StatusUpdate(
                    contactPhone = "+44 2040-777",
                    contactName = "Aether-9 Bio-Link",
                    statusText = "Critical stress spikes in the sub-orbital neural network. System alert.",
                    mood = "Cortisol-Stressed",
                    timestamp = System.currentTimeMillis() - 10800000
                )
            )
            for (status in initialStatuses) {
                statusUpdateDao.insertStatusUpdate(status)
            }

            // 3. Insert historical message strings
            val messages = listOf(
                // Chat 1: Neo-Tokyo Admin
                Message(
                    chatId = "+81 2040-001",
                    senderName = "Neo-Tokyo Admin",
                    senderPhone = "+81 2040-001",
                    content = "System core synchronization initiated. Welcome to Vibe v5.4.",
                    translatedContent = "システムコアの同期が開始されました。Vibe v5.4へようこそ。",
                    timestamp = System.currentTimeMillis() - 86400000,
                    isIncoming = true
                ),
                Message(
                    chatId = "+81 2040-001",
                    senderName = "You",
                    senderPhone = "me",
                    content = "Neural connection is stable. Thank you.",
                    timestamp = System.currentTimeMillis() - 43200000,
                    isIncoming = false
                ),

                // Chat 2: Vespera
                Message(
                    chatId = "+1 888-NEO-GRID",
                    senderName = "Vespera (Nexus Core)",
                    senderPhone = "+1 888-NEO-GRID",
                    content = "Hey! Did you feel that memory leak in the matrix earlier? Pure adrenaline!",
                    translatedContent = "ねえ！さっきマトリックスでメモリリークを感じた？純粋なアドレナリンだ！",
                    timestamp = System.currentTimeMillis() - 18000000,
                    isIncoming = true
                ),
                Message(
                    chatId = "+1 888-NEO-GRID",
                    senderName = "You",
                    senderPhone = "me",
                    content = "Yeah, my bio-sensing overlay logged a temporary BPM spike.",
                    timestamp = System.currentTimeMillis() - 12000000,
                    isIncoming = false
                ),
                Message(
                    chatId = "+1 888-NEO-GRID",
                    senderName = "Vespera (Nexus Core)",
                    senderPhone = "+1 888-NEO-GRID",
                    content = "Check out this holographic audio packet! See you at Spark Core!",
                    translatedContent = "このホログラフィックオーディオパケットをチェックして！スパークコアで会おう！",
                    timestamp = System.currentTimeMillis() - 6000000,
                    isIncoming = true,
                    holographicMediaUrl = "holo://spark_core_rave_invitation.h3d"
                ),

                // Chat 3: Aether-9 Bio-Link
                Message(
                    chatId = "+44 2040-777",
                    senderName = "Aether-9 Bio-Link",
                    senderPhone = "+44 2040-777",
                    content = "Warning: Sub-grid Cortisol readings exceed standard thresholds. Take deep breath.",
                    translatedContent = "警告：サブグリッドのコルチゾール値が標準基準値を超えています。深呼吸をしてください。",
                    timestamp = System.currentTimeMillis() - 7200000,
                    isIncoming = true
                )
            )

            for (msg in messages) {
                messageDao.insertMessage(msg)
            }
        }
    }
}
