package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.text.TextStyle
import com.example.data.Contact
import com.example.data.Message
import com.example.ui.components.*
import com.example.viewmodel.VibeViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun MainHubScreen(
    viewModel: VibeViewModel,
    modifier: Modifier = Modifier
) {
    val contacts by viewModel.allContacts.collectAsState()
    val messages by viewModel.allMessages.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val isAiProxyEnabled by viewModel.isAiProxyEnabled.collectAsState()
    val isNeuralLinkEnabled by viewModel.isNeuralLinkEnabled.collectAsState()

    var showAddContactDialog by remember { mutableStateOf(false) }
    var selectedFilter by remember { mutableStateOf("All") } // "All", "Unread", "Groups"

    // Group chat templates
    val staticGroups = listOf(
        Contact(name = "NEO-TOKYO CORE", phoneNumber = "group_tokyo_core", isSynced = true, currentMood = "Highly Excited", baseBpm = 95),
        Contact(name = "ORBITAL SHIP-7", phoneNumber = "group_orbital_7", isSynced = true, currentMood = "Calm", baseBpm = 68)
    )

    // Filtered contact list
    val filteredChats = remember(contacts, messages, searchQuery, selectedFilter) {
        val allPossibleChats = contacts + staticGroups
        allPossibleChats.filter { chat ->
            // Search query filter
            val matchesQuery = chat.name.contains(searchQuery, ignoreCase = true) ||
                    chat.phoneNumber.contains(searchQuery, ignoreCase = true)

            // Category filter
            val matchesFilter = when (selectedFilter) {
                "Groups" -> chat.phoneNumber.startsWith("group_")
                "Unread" -> {
                    // check if last message is unread
                    val chatMessages = messages.filter { it.chatId == chat.phoneNumber }
                    chatMessages.isNotEmpty() && chatMessages.last().isIncoming && chatMessages.last().isUnread
                }
                else -> true // "All"
            }

            matchesQuery && matchesFilter
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            
            // Header Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Vibe",
                        style = TextStyle(
                            brush = Brush.linearGradient(
                                colors = listOf(Color.White, Color.White.copy(alpha = 0.40f))
                            )
                        ),
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Light,
                        fontFamily = FontFamily.SansSerif,
                        letterSpacing = (-1.5).sp
                    )
                    Text(
                        text = "ULTRA-FUTURISTIC INTERFACE",
                        color = CyberCyan.copy(alpha = 0.8f),
                        fontSize = 9.sp,
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                }

                // Add contact trigger button (48dp+ interactive size)
                IconButton(
                    onClick = { showAddContactDialog = true },
                    modifier = Modifier
                        .testTag("add_contact_button")
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(Color(0x19FFFFFF))
                        .border(1.dp, CyberCyan.copy(alpha = 0.3f), CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Save New Contact",
                        tint = CyberCyan
                    )
                }
            }

            // AI proxy & Neural link quick overlays
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    FuturisticToggle(
                        label = "AI PROXY CLONE",
                        checked = isAiProxyEnabled,
                        onCheckedChange = { viewModel.toggleAiProxy() },
                        activeColor = CyberPink,
                        modifier = Modifier.weight(1f).testTag("ai_proxy_toggle")
                    )

                    FuturisticToggle(
                        label = "NEURAL LINK LINK",
                        checked = isNeuralLinkEnabled,
                        onCheckedChange = { viewModel.toggleNeuralLink() },
                        activeColor = CyberCyan,
                        modifier = Modifier.weight(1f).testTag("neural_link_toggle")
                    )
                }
            }

            // Search Bar Component
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setQuery(it) },
                placeholder = { Text("Search Synced Nodes & Groups...", color = Color.Gray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = CyberCyan,
                    unfocusedBorderColor = Color.Gray.copy(alpha = 0.3f),
                    focusedContainerColor = Color(0x0AFFFFFF),
                    unfocusedContainerColor = Color(0x0AFFFFFF)
                ),
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = "Search Icon", tint = CyberCyan)
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_bar")
                    .padding(horizontal = 20.dp, vertical = 10.dp)
            )

            // Category Filter Pills (All, Unread, Groups)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("All", "Unread", "Groups").forEach { filter ->
                    val isSelected = selectedFilter == filter
                    Box(
                        modifier = Modifier
                            .testTag("filter_pill_$filter")
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (isSelected) CyberCyan.copy(alpha = 0.20f) else Color(0x13FFFFFF))
                            .border(
                                1.dp,
                                if (isSelected) CyberCyan.copy(alpha = 0.40f) else Color(0x2BFFFFFF),
                                RoundedCornerShape(20.dp)
                            )
                            .clickable { selectedFilter = filter }
                            .padding(horizontal = 20.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = filter.uppercase(),
                            color = if (isSelected) CyberCyan else Color(0xFFE2E8F0),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.SansSerif
                        )
                    }
                }
            }

            // Chats list (clones WhatsApp layout structures closely)
            if (filteredChats.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Chat,
                            contentDescription = "No Chats",
                            tint = Color.Gray.copy(alpha = 0.5f),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "NO COGNITIVE TRANSMISSIONS FOUND",
                            color = Color.Gray,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(filteredChats) { chat ->
                        val isGroup = chat.phoneNumber.startsWith("group_")
                        val chatMessages = messages.filter { it.chatId == chat.phoneNumber }
                        val lastMsg = chatMessages.lastOrNull()
                        
                        ChatRow(
                            contact = chat,
                            isGroup = isGroup,
                            lastMessage = lastMsg,
                            isNeuralLinkEnabled = isNeuralLinkEnabled,
                            onClick = {
                                viewModel.selectChat(chat.phoneNumber, chat.name)
                            }
                        )
                    }
                }
            }
        }

        // Floating Dialog to add manual contacts
        if (showAddContactDialog) {
            AddContactDialog(
                onDismiss = { showAddContactDialog = false },
                onSave = { name, phone ->
                    viewModel.saveNewContact(name, phone)
                    showAddContactDialog = false
                }
            )
        }
    }
}

@Composable
fun ChatRow(
    contact: Contact,
    isGroup: Boolean,
    lastMessage: Message?,
    isNeuralLinkEnabled: Boolean,
    onClick: () -> Unit
) {
    val isUnread = lastMessage?.isIncoming == true && lastMessage.isUnread
    
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("chat_row_${contact.phoneNumber}")
            .clip(RoundedCornerShape(16.dp))
            .background(if (isUnread) Color(0x0AFFFFFF) else Color.Transparent)
            .border(
                width = 1.dp,
                color = if (isUnread) Color(0x0DFFFFFF) else Color.Transparent,
                shape = RoundedCornerShape(16.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left Avatar wrapped in Glowing Mood Ring (if direct chat)
        if (isGroup) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(CyberPink.copy(alpha = 0.2f))
                    .border(1.dp, CyberPink.copy(alpha = 0.5f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Group,
                    contentDescription = "Group Icon",
                    tint = CyberPink,
                    modifier = Modifier.size(26.dp)
                )
            }
        } else {
            MoodRingAvatar(
                avatarSeed = contact.avatarSeed,
                mood = contact.currentMood,
                size = 52.dp,
                bpm = contact.baseBpm
            )
        }

        Spacer(modifier = Modifier.width(16.dp))

        // Center Area: Chat Name + Last Message
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.Center
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = contact.name,
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.SansSerif,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                
                // Message timestamp
                val timeString = lastMessage?.let {
                    val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
                    sdf.format(Date(it.timestamp))
                } ?: "20:40"
                
                Text(
                    text = timeString,
                    color = if (isUnread) CyberCyan else Color.Gray,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = if (isUnread) FontWeight.Bold else FontWeight.Normal
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Last message body (with Neural Link dynamic translated preview)
            val displayText = if (lastMessage != null) {
                if (isNeuralLinkEnabled && lastMessage.translatedContent != null) {
                    "🌐 " + lastMessage.translatedContent
                } else {
                    lastMessage.content
                }
            } else {
                if (isGroup) "No transmissions in group core." else "Establish direct telemetry connection."
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = displayText,
                    color = if (isUnread) Color.White.copy(alpha = 0.9f) else Color.Gray,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                
                if (isUnread) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .clip(CircleShape)
                            .background(CyberCyan),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "1",
                            color = Color.Black,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // Right Area: Live Heart rate overlay for direct contacts
        if (!isGroup) {
            Spacer(modifier = Modifier.width(12.dp))
            // Emotion Bio-Sensing Live Indicator
            EmotionBioOverlay(
                bpm = contact.baseBpm,
                modifier = Modifier.align(Alignment.CenterVertically)
            )
        }
    }
}

@Composable
fun AddContactDialog(
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        FrostedGlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight(),
            borderGlowColor = CyberCyan
        ) {
            Text(
                text = "REGISTER NEW COGNITIVE NODE",
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(bottom = 14.dp)
            )

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Node Owner Name", color = Color.Gray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = CyberCyan,
                    unfocusedBorderColor = Color.Gray
                ),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dialog_contact_name")
                    .padding(bottom = 12.dp)
            )

            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it },
                label = { Text("Quantum Node Address", color = Color.Gray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = CyberCyan,
                    unfocusedBorderColor = Color.Gray
                ),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dialog_contact_phone")
                    .padding(bottom = 12.dp)
            )

            errorMsg?.let { msg ->
                Text(
                    text = msg,
                    color = CyberRed,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(bottom = 12.dp)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("dialog_cancel")
                ) {
                    Text("ABORT", color = Color.Gray, fontFamily = FontFamily.Monospace)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = {
                        if (name.isBlank() || phone.isBlank()) {
                            errorMsg = "ERROR: SIGNATURE MANDATORY"
                        } else {
                            onSave(name, phone)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                    modifier = Modifier.testTag("dialog_save")
                ) {
                    Text("SYNC NODE", color = Color.Black, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}
