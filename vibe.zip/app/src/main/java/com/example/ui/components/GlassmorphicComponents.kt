package com.example.ui.components

import androidx.compose.animation.animateColor
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.sin

// Theme Colors
val CyberDark = Color(0xFF05070A)
val CyberPurple = Color(0xFF0F0B1E)
val CyberPink = Color(0xFFFF007A)
val CyberCyan = Color(0xFF00F5FF)
val CyberGreen = Color(0xFF00FF66)
val CyberRed = Color(0xFFFF2A2A)

val GlassBackground = Color(0x13FFFFFF)
val GlassBorder = Color(0x2BFFFFFF)

@Composable
fun CyberBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(CyberDark)
            .drawBehind {
                // Draw a subtle futuristic digital matrix grid in the background
                val gridSize = 60.dp.toPx()
                val gridColor = Color(0x0600F5FF)
                val width = size.width
                val height = size.height

                // Vertical lines
                var x = 0f
                while (x < width) {
                    drawLine(
                        color = gridColor,
                        start = Offset(x, 0f),
                        end = Offset(x, height),
                        strokeWidth = 1f
                    )
                    x += gridSize
                }

                // Horizontal lines
                var y = 0f
                while (y < height) {
                    drawLine(
                        color = gridColor,
                        start = Offset(0f, y),
                        end = Offset(width, y),
                        strokeWidth = 1f
                    )
                    y += gridSize
                }

                // Add an ambient neon radial glow at the top-right
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0x1AFF007A), Color.Transparent),
                        center = Offset(width * 0.8f, height * 0.2f),
                        radius = width * 0.6f
                    ),
                    center = Offset(width * 0.8f, height * 0.2f),
                    radius = width * 0.6f
                )

                // Add an ambient cyan radial glow at the bottom-left
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0x1400F5FF), Color.Transparent),
                        center = Offset(width * 0.2f, height * 0.8f),
                        radius = width * 0.6f
                    ),
                    center = Offset(width * 0.2f, height * 0.8f),
                    radius = width * 0.6f
                )
            }
    ) {
        content()
    }
}

@Composable
fun FrostedGlassCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    borderGlowColor: Color = GlassBorder,
    cornerRadius: Dp = 16.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    val clickableModifier = if (onClick != null) {
        Modifier.clickable(onClick = onClick)
    } else {
        Modifier
    }

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(cornerRadius))
            .background(Color(0x0AFFFFFF)) // Pure ultra-thin frosted dark background
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        borderGlowColor.copy(alpha = 0.35f),
                        Color(0x0AFFFFFF),
                        borderGlowColor.copy(alpha = 0.15f)
                    )
                ),
                shape = RoundedCornerShape(cornerRadius)
            )
            .then(clickableModifier)
            .padding(16.dp)
    ) {
        content()
    }
}

@Composable
fun MoodRingAvatar(
    avatarSeed: Int,
    mood: String,
    modifier: Modifier = Modifier,
    size: Dp = 52.dp,
    isSelf: Boolean = false,
    bpm: Int? = null
) {
    val ringColor = when (mood) {
        "Calm" -> CyberCyan
        "Highly Excited" -> CyberPink
        "Cortisol-Stressed" -> Color(0xFFFFA500) // Beautiful high-fidelity orange from HTML
        else -> CyberCyan
    }

    // Dynamic rotation and scale pulse for futuristic feel
    val infiniteTransition = rememberInfiniteTransition(label = "mood_pulse")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (mood == "Highly Excited") 1.08f else if (mood == "Cortisol-Stressed") 1.05f else 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (mood == "Highly Excited") 800 else 1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Box(
        modifier = modifier
            .size(size)
            .testTag("mood_ring_avatar_${mood}"),
        contentAlignment = Alignment.Center
    ) {
        // Glowing Neon Mood Ring
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .size(size)
        ) {
            // Draw dual rings
            drawCircle(
                color = ringColor.copy(alpha = 0.15f * pulseScale),
                radius = (size.toPx() / 2) - 2f,
                style = Stroke(width = 6f)
            )
            drawCircle(
                brush = Brush.sweepGradient(
                    colors = listOf(ringColor, ringColor.copy(alpha = 0.2f), ringColor),
                    center = center
                ),
                radius = (size.toPx() / 2) - 2f,
                style = Stroke(width = 3.5f)
            )
        }

        // Inner Avatar Card
        Box(
            modifier = Modifier
                .size(size - 8.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color(0xFF1E293B), Color(0xFF0F172A))
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            // Display synthetic avatar initials or symbols
            val letter = if (isSelf) "ME" else {
                val characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
                characters[avatarSeed % characters.length].toString()
            }
            Text(
                text = letter,
                color = ringColor,
                fontSize = (size.value * 0.35f).sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )

            // Online indicator dot if bpm is null
            if (bpm == null) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(CyberGreen)
                )
            }
        }

        // Beautiful futuristic BPM badge overlay
        if (bpm != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .offset(x = 4.dp, y = 4.dp)
                    .background(Color.Black, RoundedCornerShape(4.dp))
                    .border(0.5.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                    .padding(horizontal = 4.dp, vertical = 1.dp)
            ) {
                Text(
                    text = "$bpm BPM",
                    color = ringColor,
                    fontSize = 7.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun EmotionBioOverlay(
    bpm: Int,
    modifier: Modifier = Modifier
) {
    val heartColor = when {
        bpm > 110 -> CyberRed
        bpm > 90 -> CyberPink
        else -> CyberCyan
    }

    val infiniteTransition = rememberInfiniteTransition(label = "heart_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (bpm > 100) 1.25f else 1.12f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (bpm > 100) 400 else 850, easing = LinearOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0x19FFFFFF))
            .border(0.5.dp, heartColor.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Default.Favorite,
            contentDescription = "Simulated Heart Beat",
            tint = heartColor,
            modifier = Modifier
                .size(14.dp)
                .align(Alignment.CenterVertically)
                .drawBehind {
                    // Pulsing backdrop shadow
                    drawCircle(
                        color = heartColor.copy(alpha = 0.3f),
                        radius = size.width * pulseScale
                    )
                }
        )
        Spacer(modifier = Modifier.width(6.dp))
        Column(horizontalAlignment = Alignment.Start) {
            Text(
                text = "$bpm BPM",
                color = Color.White,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = when {
                    bpm > 110 -> "CORTISOL SPIKE"
                    bpm > 90 -> "EXCITED"
                    else -> "STABLE NODE"
                },
                color = heartColor,
                fontSize = 8.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = FontFamily.Monospace
            )
        }

        Spacer(modifier = Modifier.width(6.dp))

        // Mini Canvas drawing real-time heart-rate spark line
        Canvas(
            modifier = Modifier
                .width(36.dp)
                .height(14.dp)
        ) {
            val width = size.width
            val height = size.height
            val points = mutableListOf<Offset>()
            val steps = 15

            for (i in 0..steps) {
                val x = (width / steps) * i
                // Generate simulated ecg pulse wave
                val y = if (i == 6 || i == 8) {
                    height * 0.1f
                } else if (i == 7) {
                    height * 0.9f
                } else {
                    height * 0.5f + (sin(i.toDouble() + System.currentTimeMillis() * 0.005) * 3f).toFloat()
                }
                points.add(Offset(x, y))
            }

            for (i in 0 until points.size - 1) {
                drawLine(
                    color = heartColor,
                    start = points[i],
                    end = points[i + 1],
                    strokeWidth = 2.5f
                )
            }
        }
    }
}

@Composable
fun HolographicMediaButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "holo_rotation")
    val projectionAngle by infiniteTransition.animateFloat(
        initialValue = -15f,
        targetValue = 15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "projection"
    )

    IconButton(
        onClick = onClick,
        modifier = modifier
            .testTag("holographic_media_button")
            .size(44.dp)
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    colors = listOf(Color(0x3300E5FF), Color(0x1100E5FF))
                )
            )
            .border(1.dp, CyberCyan.copy(alpha = 0.4f), CircleShape)
    ) {
        Box(contentAlignment = Alignment.Center) {
            // Draw visual projector laser beam ray on behind canvas
            Canvas(
                modifier = Modifier
                    .size(50.dp)
                    .offset(y = (-12).dp)
            ) {
                val path = androidx.compose.ui.graphics.Path().apply {
                    moveTo(size.width / 2f, size.height * 0.8f)
                    lineTo(size.width * 0.1f + projectionAngle, size.height * 0.1f)
                    lineTo(size.width * 0.9f - projectionAngle, size.height * 0.1f)
                    close()
                }
                drawPath(
                    path = path,
                    brush = Brush.verticalGradient(
                        colors = listOf(CyberCyan.copy(alpha = 0.25f), Color.Transparent)
                    )
                )
            }

            Icon(
                imageVector = Icons.Default.Videocam,
                contentDescription = "Holographic Projection",
                tint = CyberCyan,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
fun FuturisticToggle(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
    activeColor: Color = CyberCyan
) {
    val transition = updateTransition(targetState = checked, label = "toggle_anim")
    val thumbOffset by transition.animateDp(
        transitionSpec = { spring(stiffness = Spring.StiffnessMedium) },
        label = "thumb_pos"
    ) { if (it) 20.dp else 2.dp }

    val trackColor by transition.animateColor(
        label = "track_color"
    ) { if (it) activeColor.copy(alpha = 0.25f) else Color(0x19FFFFFF) }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0x0AFFFFFF))
            .border(0.5.dp, GlassBorder.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
            .clickable { onCheckedChange(!checked) }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.SansSerif
            )
            Text(
                text = if (checked) "CORE ONLINE" else "STANDBY / DIRECT",
                color = if (checked) activeColor else Color.Gray,
                fontSize = 9.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )
        }

        // Custom Neon Slider Switch
        Box(
            modifier = Modifier
                .width(44.dp)
                .height(24.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(trackColor)
                .border(
                    1.dp,
                    if (checked) activeColor.copy(alpha = 0.8f) else Color.Gray.copy(alpha = 0.3f),
                    RoundedCornerShape(12.dp)
                )
                .padding(2.dp)
        ) {
            Box(
                modifier = Modifier
                    .offset(x = thumbOffset)
                    .size(18.dp)
                    .clip(CircleShape)
                    .background(if (checked) activeColor else Color.LightGray)
                    .drawBehind {
                        if (checked) {
                            // Neon light halo around the knob
                            drawCircle(
                                color = activeColor.copy(alpha = 0.6f),
                                radius = size.width * 1.4f
                            )
                        }
                    }
            )
        }
    }
}
