package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.ModeFanOff
import androidx.compose.material.icons.filled.Mood
import androidx.compose.material.icons.filled.MoodBad
import androidx.compose.material.icons.filled.Tag
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.StatusUpdate
import com.example.ui.components.*
import com.example.viewmodel.VibeViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun UpdatesScreen(
    viewModel: VibeViewModel,
    modifier: Modifier = Modifier
) {
    val statusUpdates by viewModel.allStatusUpdates.collectAsState()
    val loggedInName by viewModel.loggedInName.collectAsState()

    var newStatusText by remember { mutableStateOf("") }
    var selectedMood by remember { mutableStateOf("Calm") } // "Calm", "Highly Excited", "Cortisol-Stressed"

    // Separate user status and other status updates
    val userUpdates = remember(statusUpdates) {
        statusUpdates.filter { it.contactName.contains("You", ignoreCase = true) }
    }
    val contactUpdates = remember(statusUpdates) {
        statusUpdates.filter { !it.contactName.contains("You", ignoreCase = true) }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp)
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Title Header
        Text(
            text = "Telemetry",
            style = TextStyle(
                brush = Brush.linearGradient(
                    colors = listOf(Color.White, Color.White.copy(alpha = 0.40f))
                )
            ),
            fontSize = 32.sp,
            fontWeight = FontWeight.Light,
            fontFamily = FontFamily.SansSerif,
            letterSpacing = (-1.5).sp
        )
        Text(
            text = "QUANTUM COGNITIVE MOOD INDICATORS",
            color = CyberPink.copy(alpha = 0.8f),
            fontSize = 9.sp,
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Post status card (Frosted Glass)
        FrostedGlassCard(
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
                .testTag("post_status_card"),
            borderGlowColor = CyberPink
        ) {
            Text(
                text = "BROADCAST YOUR VIBE",
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            // Status content typing field
            OutlinedTextField(
                value = newStatusText,
                onValueChange = { newStatusText = it },
                placeholder = { Text("What's in your thoughts?", color = Color.Gray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = CyberPink,
                    unfocusedBorderColor = Color.Gray.copy(alpha = 0.4f)
                ),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("status_input_field")
                    .padding(bottom = 12.dp)
            )

            // Mood selection row (touch target 48dp+ for each pill)
            Text(
                text = "SELECT BIO-STATE PRESET:",
                color = Color.Gray,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 6.dp)
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val moods = listOf(
                    Triple("Calm", CyberCyan, Icons.Default.Mood),
                    Triple("Highly Excited", CyberPink, Icons.Default.ElectricBolt),
                    Triple("Cortisol-Stressed", CyberRed, Icons.Default.MoodBad)
                )

                moods.forEach { (moodName, moodColor, icon) ->
                    val isSelected = selectedMood == moodName
                    Row(
                        modifier = Modifier
                            .testTag("mood_selector_$moodName")
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) moodColor.copy(alpha = 0.25f) else Color(0x11FFFFFF))
                            .border(1.dp, if (isSelected) moodColor else Color.Transparent, RoundedCornerShape(8.dp))
                            .clickable { selectedMood = moodName }
                            .padding(vertical = 12.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = moodName,
                            tint = moodColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (moodName == "Highly Excited") "EXCITED" else if (moodName == "Cortisol-Stressed") "STRESSED" else "CALM",
                            color = if (isSelected) Color.White else Color.Gray,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            // Broadcast action button (height 48dp+)
            Button(
                onClick = {
                    if (newStatusText.isNotBlank()) {
                        viewModel.postUserStatus(newStatusText, selectedMood)
                        newStatusText = ""
                    }
                },
                enabled = newStatusText.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = CyberPink),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("broadcast_status_button")
                    .height(48.dp)
            ) {
                Text(
                    text = "TRANSMIT VIBE NODE",
                    color = Color.Black,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Personal Status Section
        Text(
            text = "YOUR ACTIVE TRANSMISSION",
            color = Color.Gray,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        if (userUpdates.isEmpty()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                MoodRingAvatar(avatarSeed = 5, mood = "Calm", isSelf = true, size = 52.dp)
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = "No active broadcast",
                        color = Color.Gray,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Initialize status matrix above.",
                        color = Color.DarkGray,
                        fontSize = 11.sp
                    )
                }
            }
        } else {
            userUpdates.forEach { status ->
                StatusRow(status = status, isSelf = true)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Contacts' Status updates Section
        Text(
            text = "SYNAPSE UPDATES FEED",
            color = Color.Gray,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        if (contactUpdates.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "NO COGNITIVE BIO-STATES REPORTED",
                    color = Color.DarkGray,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(contactUpdates) { status ->
                    StatusRow(status = status, isSelf = false)
                }
            }
        }
    }
}

@Composable
fun StatusRow(
    status: StatusUpdate,
    isSelf: Boolean
) {
    val ringColor = when (status.mood) {
        "Calm" -> CyberCyan
        "Highly Excited" -> CyberPink
        "Cortisol-Stressed" -> Color(0xFFFFA500) // Beautiful cyberpunk orange!
        else -> CyberCyan
    }

    val bpm = when (status.mood) {
        "Calm" -> 64 + (status.avatarSeed % 12)
        "Highly Excited" -> 112 + (status.avatarSeed % 15)
        "Cortisol-Stressed" -> 138 + (status.avatarSeed % 10)
        else -> 72
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("status_row_${status.contactPhone}")
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        MoodRingAvatar(
            avatarSeed = status.avatarSeed,
            mood = status.mood,
            size = 54.dp,
            isSelf = isSelf,
            bpm = bpm
        )

        Spacer(modifier = Modifier.width(16.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isSelf) "You (Neural Core)" else status.contactName,
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                val timeStr = remember(status.timestamp) {
                    val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
                    sdf.format(Date(status.timestamp))
                }
                Text(
                    text = timeStr,
                    color = Color.Gray,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = status.statusText,
                color = Color.White.copy(alpha = 0.9f),
                fontSize = 13.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(ringColor)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = when (status.mood) {
                        "Calm" -> "STABLE CALM STATE"
                        "Highly Excited" -> "SPIKED ADRENALINE EXCITEMENT"
                        "Cortisol-Stressed" -> "HIGH CORTISOL ALERT LEVEL"
                        else -> "CALIBRATED"
                    },
                    color = ringColor,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
