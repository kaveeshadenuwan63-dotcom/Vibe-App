package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Message
import com.example.ui.components.*
import com.example.viewmodel.Screen
import com.example.viewmodel.VibeViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ChatScreen(
    viewModel: VibeViewModel,
    modifier: Modifier = Modifier
) {
    val selectedChatId by viewModel.selectedChatId.collectAsState()
    val selectedChatName by viewModel.selectedChatName.collectAsState()
    val messages by viewModel.allMessages.collectAsState()
    val isNeuralLinkEnabled by viewModel.isNeuralLinkEnabled.collectAsState()
    val liveBpm by viewModel.liveBpm.collectAsState()

    var textInput by remember { mutableStateOf("") }
    var showingCallingOverlay by remember { mutableStateOf<String?>(null) } // "Voice", "Video", null

    val chatMessages = remember(messages, selectedChatId) {
        messages.filter { it.chatId == selectedChatId }
    }

    val isGroup = selectedChatId?.startsWith("group_") == true

    Box(modifier = modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            
            // Top Header Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
                    .statusBarsPadding(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Back button (48dp+ target)
                IconButton(
                    onClick = { viewModel.setScreen(Screen.MainHub) },
                    modifier = Modifier
                        .testTag("back_button")
                        .size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Go Back",
                        tint = Color.White
                    )
                }

                // Chat Info Title
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(start = 4.dp)
                ) {
                    Text(
                        text = selectedChatName ?: "DIRECT SYNC",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                    Text(
                        text = if (isGroup) "DECRYPTED SECURE HUB" else "COGNITIVE CONNECTION",
                        color = CyberCyan,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Bio Sensing heart-rate display
                if (!isGroup) {
                    EmotionBioOverlay(
                        bpm = liveBpm,
                        modifier = Modifier.padding(end = 8.dp)
                    )
                }

                // Voice Call (48dp+ target)
                IconButton(
                    onClick = { showingCallingOverlay = "Voice" },
                    modifier = Modifier
                        .testTag("voice_call_icon")
                        .size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = "Simulated Voice Call",
                        tint = CyberCyan
                    )
                }

                // Video Call (48dp+ target)
                IconButton(
                    onClick = { showingCallingOverlay = "Video" },
                    modifier = Modifier
                        .testTag("video_call_icon")
                        .size(48.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Videocam,
                        contentDescription = "Simulated Video Call",
                        tint = CyberPink
                    )
                }
            }

            // Divider Line
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(0.5.dp)
                    .background(GlassBorder.copy(alpha = 0.2f))
            )

            // Message History Scroll List
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(top = 12.dp, bottom = 12.dp)
            ) {
                items(chatMessages) { message ->
                    MessageBubble(message = message, isNeuralLinkEnabled = isNeuralLinkEnabled)
                }
            }

            // Bottom Typing Bar Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Holographic Media project button
                HolographicMediaButton(
                    onClick = {
                        viewModel.sendMessage(
                            content = "🌌 [HOLOGRAPHIC CLIP BROADCAST] Deployed live 3D coordinate transmission packet.",
                            holographicMediaUrl = "holo://live_grid_${(100..999).random()}.h3d"
                        )
                    }
                )

                Spacer(modifier = Modifier.width(8.dp))

                // Text field (height 48dp+)
                OutlinedTextField(
                    value = textInput,
                    onValueChange = { textInput = it },
                    placeholder = { Text("Synchronize message...", color = Color.Gray) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = CyberCyan,
                        unfocusedBorderColor = Color.Gray.copy(alpha = 0.4f),
                        focusedContainerColor = Color(0x13FFFFFF),
                        unfocusedContainerColor = Color(0x13FFFFFF)
                    ),
                    shape = RoundedCornerShape(24.dp),
                    singleLine = true,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chat_input_field")
                        .heightIn(min = 48.dp)
                )

                Spacer(modifier = Modifier.width(8.dp))

                // Send Button (48dp+ touch target)
                IconButton(
                    onClick = {
                        if (textInput.isNotBlank()) {
                            viewModel.sendMessage(textInput)
                            textInput = ""
                        }
                    },
                    enabled = textInput.isNotBlank(),
                    modifier = Modifier
                        .testTag("chat_send_button")
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(if (textInput.isNotBlank()) CyberCyan else Color(0x19FFFFFF))
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Send Message",
                        tint = if (textInput.isNotBlank()) Color.Black else Color.Gray
                    )
                }
            }
        }

        // Animated Interactive Holographic Calling Overlay
        if (showingCallingOverlay != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xE60A0915)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "VIBE HOLOGRAPHIC ${showingCallingOverlay?.uppercase()}",
                        color = CyberCyan,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = selectedChatName ?: "NODE",
                        color = Color.White,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "CONNECTING NEURAL LIGHT BRIDGE...",
                        color = CyberPink,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(32.dp))
                    
                    // Ring animations simulating audio wavelengths
                    CircularProgressIndicator(
                        color = CyberPink,
                        strokeWidth = 3.dp,
                        modifier = Modifier.size(80.dp)
                    )

                    Spacer(modifier = Modifier.height(60.dp))
                    
                    // End transmission button (touch target 48dp+)
                    Button(
                        onClick = { showingCallingOverlay = null },
                        colors = ButtonDefaults.buttonColors(containerColor = CyberRed),
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier
                            .testTag("end_call_button")
                            .height(48.dp)
                            .width(180.dp)
                    ) {
                        Text(
                            text = "DISCONNECT",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MessageBubble(
    message: Message,
    isNeuralLinkEnabled: Boolean
) {
    val isMe = message.senderPhone == "me" || message.senderPhone == "me_proxy"
    val isProxy = message.senderPhone == "me_proxy"

    val align = if (isMe) Alignment.End else Alignment.Start
    val bubbleColor = when {
        isProxy -> Brush.horizontalGradient(colors = listOf(CyberPurple, CyberPink.copy(alpha = 0.5f)))
        isMe -> Brush.horizontalGradient(colors = listOf(CyberDark, CyberCyan.copy(alpha = 0.4f)))
        else -> Brush.horizontalGradient(colors = listOf(Color(0x1FFFFFFF), Color(0x0FFFFFFF)))
    }
    
    val bubbleBorder = when {
        isProxy -> CyberPink.copy(alpha = 0.6f)
        isMe -> CyberCyan.copy(alpha = 0.5f)
        else -> GlassBorder.copy(alpha = 0.2f)
    }

    val bubbleShape = if (isMe) {
        RoundedCornerShape(16.dp, 16.dp, 2.dp, 16.dp)
    } else {
        RoundedCornerShape(16.dp, 16.dp, 16.dp, 2.dp)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("message_item_${message.id}"),
        horizontalAlignment = align
    ) {
        // Display Proxy Tag or Sender Name
        Row(
            modifier = Modifier.padding(bottom = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isProxy) {
                Text(
                    text = "🤖 AUTONOMOUS CLONE REPLY",
                    color = CyberPink,
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(end = 4.dp)
                )
            }
            Text(
                text = if (isMe && !isProxy) "YOU" else message.senderName.uppercase(),
                color = Color.Gray,
                fontSize = 9.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = FontFamily.Monospace
            )
        }

        // Bubble Content
        Column(
            modifier = Modifier
                .widthIn(max = 280.dp)
                .clip(bubbleShape)
                .background(bubbleColor)
                .border(0.5.dp, bubbleBorder, bubbleShape)
                .padding(12.dp)
        ) {
            // Main Content
            Text(
                text = message.content,
                color = Color.White,
                fontSize = 14.sp
            )

            // Neural Link live Translation
            if (isNeuralLinkEnabled && message.translatedContent != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0x1100E5FF))
                        .padding(6.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = "Translation",
                                tint = CyberCyan,
                                modifier = Modifier.size(10.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "AUTO-TRANSLATION NEURAL LINK",
                                color = CyberCyan,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = message.translatedContent,
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.SansSerif
                        )
                    }
                }
            }

            // Holographic Projection clip simulation render
            if (message.holographicMediaUrl != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0x2200E5FF))
                        .border(1.dp, CyberCyan.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                        .clickable { /* Simulate play holographic projection */ }
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator(
                        color = CyberCyan,
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "RENDER 3D HOLO-WAVE",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = message.holographicMediaUrl,
                            color = CyberCyan,
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            // Timestamp under the bubble
            val timeStr = remember(message.timestamp) {
                val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
                sdf.format(Date(message.timestamp))
            }
            Text(
                text = timeStr,
                color = Color.Gray.copy(alpha = 0.8f),
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier
                    .align(Alignment.End)
                    .padding(top = 4.dp)
            )
        }
    }
}
