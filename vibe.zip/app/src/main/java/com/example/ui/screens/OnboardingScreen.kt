package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.TextStyle
import com.example.ui.components.*
import com.example.viewmodel.VibeViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun OnboardingScreen(
    viewModel: VibeViewModel,
    modifier: Modifier = Modifier
) {
    var phoneNumber by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isCalibrating by remember { mutableStateOf(false) }
    var calibrationProgress by remember { mutableStateOf(0) }
    var isScanningBiometric by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()

    // Pulse animation for fingerprint
    val infiniteTransition = rememberInfiniteTransition(label = "fingerprint_pulse")
    val fingerPulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    CyberBackground(modifier = modifier) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
                .navigationBarsPadding()
                .statusBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header Logo Area
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 20.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Psychology,
                    contentDescription = "Neural Link Icon",
                    tint = CyberCyan,
                    modifier = Modifier
                        .size(56.dp)
                        .drawBehind {
                            drawCircle(CyberCyan.copy(alpha = 0.25f), radius = size.width * 0.8f)
                        }
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "Vibe",
                    style = TextStyle(
                        brush = Brush.linearGradient(
                            colors = listOf(Color.White, Color.White.copy(alpha = 0.40f))
                        )
                    ),
                    fontSize = 44.sp,
                    fontWeight = FontWeight.Light,
                    fontFamily = FontFamily.SansSerif,
                    letterSpacing = (-1.5).sp,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "2040 NEURAL SYNC PROTOCOL",
                    color = CyberPink.copy(alpha = 0.8f),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.SansSerif,
                    letterSpacing = 2.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            // Main input card
            FrostedGlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .wrapContentHeight(),
                borderGlowColor = CyberCyan
            ) {
                if (!isCalibrating) {
                    Text(
                        text = "INITIALIZE BIOMETRIC TERMINAL",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    // Name Input
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Quantum Signature (Name)", color = Color.Gray) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = Color.Gray.copy(alpha = 0.5f)
                        ),
                        leadingIcon = {
                            Icon(Icons.Default.FlashOn, contentDescription = "Name Icon", tint = CyberCyan)
                        },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("onboarding_name_input")
                            .padding(bottom = 12.dp)
                    )

                    // Phone Input
                    OutlinedTextField(
                        value = phoneNumber,
                        onValueChange = { phoneNumber = it },
                        label = { Text("Quantum Phone Identifier", color = Color.Gray) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = Color.Gray.copy(alpha = 0.5f)
                        ),
                        leadingIcon = {
                            Icon(Icons.Default.Phone, contentDescription = "Phone Icon", tint = CyberCyan)
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("onboarding_phone_input")
                            .padding(bottom = 16.dp)
                    )

                    errorMessage?.let { error ->
                        Text(
                            text = error,
                            color = CyberRed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )
                    }

                    // Touch target sized finger scanner simulation
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isScanningBiometric) CyberCyan.copy(alpha = 0.15f) else Color(0x0FFFFFFF))
                            .border(
                                1.dp,
                                if (isScanningBiometric) CyberCyan else Color.Gray.copy(alpha = 0.3f),
                                RoundedCornerShape(12.dp)
                            )
                            .clickable {
                                if (name.isBlank() || phoneNumber.isBlank()) {
                                    errorMessage = "ERROR: QUANTUM FIELDS MANDATORY"
                                    return@clickable
                                }
                                errorMessage = null
                                isScanningBiometric = true
                                coroutineScope.launch {
                                    delay(1500)
                                    isScanningBiometric = false
                                    isCalibrating = true
                                    // Count-up calibration loop
                                    for (progress in 0..100 step 5) {
                                        calibrationProgress = progress
                                        delay(80)
                                    }
                                    viewModel.login(phoneNumber, name)
                                }
                            }
                            .testTag("biometric_scanner_onboarding")
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Fingerprint,
                            contentDescription = "Scan Fingerprint",
                            tint = if (isScanningBiometric) CyberCyan else CyberPink,
                            modifier = Modifier
                                .size(48.dp)
                                .drawBehind {
                                    if (isScanningBiometric) {
                                        drawCircle(
                                            color = CyberCyan.copy(alpha = 0.25f),
                                            radius = size.width * fingerPulseScale
                                        )
                                    }
                                }
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Column {
                            Text(
                                text = if (isScanningBiometric) "AUTHENTICATING DNA..." else "PRESS TO SCAN BIOMETRICS",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = if (isScanningBiometric) "Scanning cortical network..." else "Calibrate terminal links",
                                color = Color.Gray,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                } else {
                    // Neural calibration state
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(
                            color = CyberCyan,
                            strokeWidth = 4.dp,
                            modifier = Modifier
                                .size(64.dp)
                                .padding(8.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "NEURAL SYNCING: $calibrationProgress%",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "Stabilizing mental-grid transceiver...",
                            color = CyberCyan,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }

            // Footer
            Text(
                text = "SECURED VIA QUANTUM END-TO-END COGNITIVE MATRIX",
                color = Color.Gray.copy(alpha = 0.7f),
                fontSize = 9.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.padding(bottom = 20.dp)
            )
        }
    }
}
